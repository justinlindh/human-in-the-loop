import { registerHooks } from 'node:module';
const print = process.env.TEE_PRINT;
if (!/^[a-z0-9_]+$/.test(print ?? '')) throw new Error('TEE_PRINT required');
registerHooks({
  load(url, context, next) {
    const result = next(url, context);
    if (result.format !== 'module' || result.source == null) return result;
    let source = String(result.source);
    if (url.endsWith('/scripts/studio/platform.mjs')) {
      source = source.replace("href: 'http://scene.invalid/' };", "href: 'http://scene.invalid/' }; g.location.search += '&eras&eraArt=web2';");
    }
    if (url.endsWith('/scripts/studio/loader.mjs')) {
      source = source.replace("let source = readFileSync(new URL(url), 'utf8');", `let source = readFileSync(new URL(url), 'utf8');
        if (url.endsWith('/src/render/character.js')) {
          source = source.replace('const rand = timingRandom(opts.seed);', 'appearance = { ...appearance, wardrobeVariant: 3, eraPrint: ${JSON.stringify(print)} }; opts = { ...opts, wardrobe: "web2" }; const rand = timingRandom(opts.seed);');
        }
        if (url.endsWith('/src/render/models.js')) {
          source = source.replace('return Promise.all(names.map(loadOne))', 'return Promise.all([...new Set([...names, "era_attire"])].map(loadOne))');
        }`);
    }
    return { ...result, source };
  },
});

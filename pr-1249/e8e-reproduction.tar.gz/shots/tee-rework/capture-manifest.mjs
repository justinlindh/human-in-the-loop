import { ITEMS as original } from '../attire/capture-manifest.mjs';

export const ITEMS = [
  ...original,
  {
    id: 'tee-motion', title: 'Eight tee designs through walk, typing, celebration and a back view',
    query: 'mock=floor&eras&eraArt=web2&time=day&speed=0', seconds: 12, warmup: 0.1,
    hideUi: true, camera: [{ at: 0, target: [0, 4.5], zoom: 2.2 }],
    setup: `(async () => { await ${original[0].setup};
      const R = window.__hitlRender;
      const render = R.render.bind(R);
      R.render = (dt, opts) => { for (const c of window.attirePeople) c.update(dt); return render(dt, opts); };
    })()`,
    actions: [
      { at: 0, js: "attirePeople.forEach(c => c.setAnim('walk'));" },
      { at: 3, js: "attirePeople.forEach(c => c.setAnim('typing'));" },
      { at: 6, js: "attirePeople.forEach(c => c.setAnim('celebrate'));" },
      { at: 9, js: "attirePeople.forEach(c => { c.root.rotation.y += Math.PI; c.setAnim('idle'); });" },
    ], screenshots: [1, 4, 7, 10], size: '1920x1080', fps: 30,
  },
];

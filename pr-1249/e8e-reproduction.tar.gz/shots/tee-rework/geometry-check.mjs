import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
import { installPlatform } from '../../scripts/studio/platform.mjs';
import { installLoader } from '../../scripts/studio/loader.mjs';

const root = resolve(process.argv[2]);
installPlatform(root, { quality: 'low' });
location.search = '?eras';
installLoader({ root });
const from = path => import(pathToFileURL(resolve(root, path)).href);
const { loadModels } = await from('src/render/models.js');
const { createCharacter } = await from('src/render/character.js');
const { ROLE_COLORS } = await from('src/render/palette.js');
const { TEE_PRINTS } = await from('src/render/wardrobe.js');
await loadModels();

function surfaces(c) {
  const hash = createHash('sha256');
  let triangles = 0, draws = 0, textures = 0;
  c.root.traverse(o => {
    if (!o.userData.part) return;
    draws++;
    triangles += (o.geometry.index?.count ?? o.geometry.attributes.position.count) / 3;
    textures += o.material.map ? 1 : 0;
    hash.update(o.userData.part);
    for (const k of ['position', 'normal', 'color', 'aSurf']) {
      const a = o.geometry.attributes[k].array;
      hash.update(Buffer.from(a.buffer, a.byteOffset, a.byteLength));
    }
  });
  assert.equal(draws, 6);
  assert.equal(textures, 0);
  return { hash: hash.digest('hex'), triangles, draws, textures };
}

const output = { period: {}, tees: {} };
for (const [role, color] of Object.entries(ROLE_COLORS)) for (let build = 0; build < 3; build++) {
  for (const era of [null, 'preinternet', 'dotcom', 'dotcom-bust', 'web2']) for (const variant of [0, 1, 2]) {
    const c = createCharacter({ build, skin: build, hair: 1, wardrobeVariant: variant }, color, { role, wardrobe: era });
    output.period[`${role}/${build}/${era}/${variant}`] = surfaces(c);
    c.dispose();
  }
}
for (let build = 0; build < 3; build++) for (const print of TEE_PRINTS) {
  const c = createCharacter({ build, skin: build, hair: 1, wardrobeVariant: 3, eraPrint: print }, ROLE_COLORS.engineer, { role: 'engineer', wardrobe: 'web2' });
  output.tees[`${build}/${print}`] = surfaces(c);
  for (const pose of ['walk', 'typing', 'celebrate', 'facepalm']) {
    c.setAnim(pose); c.update(0.1); c.setShadows(false);
    const before = JSON.stringify(c.joints());
    const root = c.root, head = c.head;
    c.setWardrobe('dotcom');
    assert.equal(JSON.stringify(c.joints()), before);
    assert.equal(c.root, root); assert.equal(c.head, head);
    c.root.traverse(o => { if (o.userData.part) assert.equal(o.castShadow, false); });
    c.setWardrobe('web2');
  }
  assert.deepEqual(surfaces(c), output.tees[`${build}/${print}`]);
  c.dispose();
}
if (process.argv[4]) {
  const control = JSON.parse(readFileSync(process.argv[4], 'utf8'));
  assert.deepEqual(output.period, control.period, 'period and modern clothing buffers remain exact');
  console.log(`Unchanged period and modern controls: ${Object.keys(output.period).length} exact matches`);
}
writeFileSync(process.argv[3], JSON.stringify(output, null, 2));
console.log(`Tee builds and print variants: ${Object.keys(output.tees).length}; six body draws, zero textures; four pose transitions each pass`);
console.log(`Tee body triangle range: ${Math.min(...Object.values(output.tees).map(v => v.triangles))}..${Math.max(...Object.values(output.tees).map(v => v.triangles))}`);

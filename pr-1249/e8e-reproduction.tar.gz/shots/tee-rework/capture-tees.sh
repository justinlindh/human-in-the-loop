#!/usr/bin/env bash
set -euo pipefail
out="${1:?output directory}"
mkdir -p "$out"
for build in 0 1 2; do
  for time in day night; do
    timeout 180 nice -n 10 npm run snap -- --scenario floor --quality low --time "$time" --width 3840 --height 2160 \
      --query "eras&eraArt=web2&chars=4&build=$build&zoom=1.25" --eval "document.getElementById('ui').style.display='none'" \
      --out "$out/tees-build$build-$time.png"
  done
done

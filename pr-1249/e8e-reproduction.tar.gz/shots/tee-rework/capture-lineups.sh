#!/usr/bin/env bash
set -euo pipefail
for era in preinternet dotcom dotcom-bust web2 classic chatgbt agents consolidation plateau; do
  for time in day night; do
    timeout 180 nice -n 10 npm run snap -- --scenario floor --quality low --time "$time" \
      --query "eras&eraArt=$era&chars=3" --eval "document.getElementById('ui').style.display='none'" \
      --out "shots/tee-rework/lineup-$era-$time-low.png"
  done
  scripts/sheet.sh pair "shots/tee-rework/review-$era.png" "shots/tee-rework/lineup-$era-day-low.png" "shots/tee-rework/lineup-$era-night-low.png" --labels "$era day Low,$era night Low"
done

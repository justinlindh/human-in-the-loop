#!/usr/bin/env bash
set -euo pipefail
for print in parcel_paws onlineland y2k shoutbook tuesday beta_forever weekend ship_it; do
  TEE_PRINT="$print" NODE_OPTIONS=--import=./shots/tee-rework/tee-pose-loader.mjs \
    node blender/checks/pose.mjs --gesture facepalm --matrix views=all,postures=stand,sit,builds=all,rig=on,off --jobs 3 \
      --json "shots/tee-rework/pose-$print.json"
done

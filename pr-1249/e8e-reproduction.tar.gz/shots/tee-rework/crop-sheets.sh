#!/usr/bin/env bash
set -euo pipefail
mkdir -p shots/tee-rework/crops
names=(parcel-paws onlineland y2k shoutbook tuesday beta-forever weekend ship-it)
xs=(1420 1840 2230 2670 740 1178 1582 1955)
ys=(467 692 920 1135 850 1060 1300 1530)
for build in 0 1 2; do
  for time in day night; do
    files=()
    for i in 0 1 2 3 4 5 6 7; do
      out="shots/tee-rework/crops/build$build-$time-${names[$i]}.png"
      scripts/sheet.sh pair "$out" "shots/tee-rework/before/tees-build$build-$time.png" "shots/tee-rework/tees-build$build-$time.png" \
        --labels "${names[$i]} before,${names[$i]} after" --crop "${xs[$i]},${ys[$i]},440,330"
      files+=("$out")
    done
    scripts/sheet.sh grid "shots/tee-rework/close-build$build-$time.png" --cols 2 "${files[@]}"
  done
done
